//
//  GalleryPhotoCell.swift
//  avrio
//
//  Created by William Jattin on 3/7/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//
import UIKit

class GalleryPhotoCell: UICollectionViewCell {
    
    @IBOutlet weak var thumbnail : UIImageView!
    @IBOutlet weak var label : UILabel!
}

