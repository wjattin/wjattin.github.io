//
//  Annotation.swift
//  avrio
//
//  Created by William Jattin on 2/14/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit
import MapKit

class Annotation: MKPointAnnotation {

    var FeatureId: Int = 0
    var Price: String = ""
    var DevelopmentId : String = ""
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
