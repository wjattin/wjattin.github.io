//
//  FeatureContainer.swift
//  avrio
//
//  Created by William Jattin on 2/13/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import Foundation
import UIKit

class FeatureContainer: UIView {
    var DevelopmentID : String = ""
    @IBOutlet weak var coverImage: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var details: UILabel!

    @IBOutlet weak var models: UIButton!
    @IBAction func models(_ sender: Any) {
        print(DevelopmentID)
        DataHelper.CURRENT_VIEW["view"] = "models"
        DataHelper.CURRENT_VIEW["num"] = DevelopmentID
        //var notifArray = ["na" , DevelopmentID] as
       NotificationCenter.default.post(name: .modelList, object: DevelopmentID)
        //MapViewController.loadModels()

    }
    
    @IBOutlet weak var properties: UIButton!
    @IBAction func properties(_ sender: Any) {
        print(DevelopmentID)
       NotificationCenter.default.post(name: .propertyList, object: DevelopmentID)
        //MapViewController.loadProperties()
    }
    
    
}
extension Notification.Name {
    static let modelList = Notification.Name("modelList")
    static let propertyList = Notification.Name("propertyList")
}
