//
//  ModelsListViewCellTableViewCell.swift
//  avrio
//
//  Created by William Jattin on 2/25/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit

class ModelsListViewCellTableViewCell: UITableViewCell {
    
    @IBOutlet weak var ModelImage: UIImageView!
    @IBOutlet weak var ModelPrice: UILabel!
    @IBOutlet weak var ModelSummary: UILabel!


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
