//
//  DataHelper.swift
//  avrio
//
//  Created by William Jattin on 2/13/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit
import Foundation

class DataHelper {

static var CAPTURED_DATA = NSArray()
static var API_SETTINGS = [String : String]()
static var CURRENT_VIEW = [String :  Any]()
static var SEARCH = [String :  String]()
    
    init(){
        /* set defaults */
        DataHelper.API_SETTINGS["ROOT"] = "https://api.zenonsoft.com"
        DataHelper.API_SETTINGS["APPLICATION"] = "/application/"
        DataHelper.API_SETTINGS["VIEWS"] = "/application/views/"
        DataHelper.API_SETTINGS["DEVELOPMENTS"] = "developments.php"
        DataHelper.API_SETTINGS["BUILDERS"] = "builders.php"
        DataHelper.API_SETTINGS["MODELS"] = "models.php"
        DataHelper.API_SETTINGS["PROPERTIES"] = "properties.php"
        
        DataHelper.CURRENT_VIEW["view"] = ""
        DataHelper.CURRENT_VIEW["devnum"] = ""
        DataHelper.CURRENT_VIEW["modelnum"] = 0
        //The search filters will be by price (min -max) / Number of rooms (min) / Type of home ( Houses, Condo, Townhomes )/ Gated Community (y/n)
        DataHelper.SEARCH["min_bedrooms"] = ""
        DataHelper.SEARCH["min_bathrooms"] = ""
        DataHelper.SEARCH["expected_completion"] = ""
        DataHelper.SEARCH["property_type"] = ""
        DataHelper.SEARCH["gated"] = ""
        DataHelper.SEARCH["starting_price"] = ""
        DataHelper.SEARCH["sq_ft_max"] = ""
        DataHelper.SEARCH["sq_ft_min"] = ""


    }
    /* Functions */
    static func userKey() -> String {
        var key = "default"
        let file = "key.txt" //this is the file. we will write to and read from it
    
        let text = "" //just a text
        
        if let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            let fileURL = dir.appendingPathComponent(file)
            

            
            //reading
            do {
                 key = try String(contentsOf: fileURL, encoding: .utf8)
            }
            catch {/* error handling here */}
            
            if(key == "default") {
                //writing
                do {
                    try text.write(to: fileURL, atomically: false, encoding: .utf8)
                }
                catch {/* error handling here */}
                
            }
        }
        return key
    }
    // loadImage: Downloads an image from a url string and returns a UIImage object
    static func loadImage(imageUrl: String) -> UIImage {
        let theURL = URL(string: imageUrl)!
        
        let data = try? Data(contentsOf: theURL)
        
        let imageData = data
        // else.......need to provide a default image placeholder
        //                let theURL = URL(string: "https://api.zenonsoft.com/cmsb/uploads/kitchen-stove-sink-kitchen-counter-349749.jpeg")!
        //                let data = try? Data(contentsOf: theURL)
        //
        //                if let imageData = data {
        //
        //                    featureView.imagePreview.image = UIImage(data: imageData)
        //                }
        //
        return UIImage(data: imageData!)!
    }
    
    // This generic function will be used to make all the api calls for builder, developers, models and properties.
    static func requestData(_ parameters: [String: String]) -> Void{
        print("Requesting data")
        //.. Code process
        let url4 = URL(string: parameters["urlToRequest"]!)!
        let view : String = parameters["view"] ?? "map"

        let session4 = URLSession.shared
        let request = NSMutableURLRequest(url: url4)
        
        request.httpMethod = "POST"
        request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
        
        let paramString = "data=Hello"
        
        request.httpBody = paramString.data(using: String.Encoding.utf8)
        
        let task = session4.dataTask(with: request as URLRequest) { (data, response, error) in
            
            guard let _: Data = data, let _: URLResponse = response, error == nil else {
                
                print("*****error")
                return
            }
            do{
                //here dataResponse received from a network request
                let jsonResponse = try JSONSerialization.jsonObject(with:
                    data!, options: []) as! NSArray
                //print(jsonResponse) //Response result
                DataHelper.CAPTURED_DATA = jsonResponse
                print("DataHelper.CAPTURED_DATA")
                // print(DataHelper.CAPTURED_DATA)
                switch view {
                case "map":
                    NotificationCenter.default.post(name: .gotData, object: nil)
                case "models":
                    NotificationCenter.default.post(name: .gotModels, object: nil)
                default:
                    print("life's good")
                }
                
            } catch let parsingError {
                print("Error", parsingError)
            }
        }
        
        task.resume()
        // return data & close
    }
    //search todo....
    
    
}
extension Notification.Name {
    static let gotData = Notification.Name("gotData")
    static let gotModels = Notification.Name("gotModels")
}

