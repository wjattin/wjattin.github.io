//
//  PanoViewController.swift
//  avrio
//
//  Created by William Jattin on 3/7/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit

class PanoViewController: UIViewController, UIScrollViewDelegate {
    @IBOutlet weak var compassView: CTPieSliceView!
    @IBOutlet weak var panoramaView: CTPanoramaView!
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var imageScrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("GalleryViewController.SelectedImage")
        print(GalleryViewController.SelectedImage)
        imageScrollView.minimumZoomScale = 1.0
        imageScrollView.maximumZoomScale = 6.0
        if(DetailsViewController.GalleryType == "tour"){
        self.imageScrollView.isHidden = true
        self.panoramaView.isHidden = false

        panoramaView.frame = self.view.frame
        //let ImageDetails: NSDictionary = DetailsViewController.GalleryImages[GalleryViewController.SelectedImage] as! NSDictionary
        //let UrlPath = "https://api.zenonsoft.com" + String(ImageDetails.value(forKey: "urlPath")! as! String)
        //let PanoImage = DataHelper.loadImage(imageUrl: UrlPath)
        // Do any additional setup after loading the view.
        loadSphericalImage(image: GalleryViewController.FullScreenImages[GalleryViewController.SelectedImage])
        //loadCylindricalImage()
        panoramaView.compass = compassView
        panoramaView.controlMethod = .motion
        } else {
            self.panoramaView.isHidden = true
            self.imageScrollView.isHidden = false
            imageScrollView.frame = self.view.frame

            
            image.isUserInteractionEnabled = true
            image.frame = imageScrollView.frame
            image.image = GalleryViewController.FullScreenImages[GalleryViewController.SelectedImage]
            image.contentMode = UIView.ContentMode.scaleAspectFit
            

        }
    }

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.image
    }
    
    @IBAction func panoramaTypeTapped() {
        if panoramaView.panoramaType == .spherical {
            //loadCylindricalImage()
        } else {
            //loadSphericalImage()
        }
    }
    @IBOutlet weak var indicator: UIButton!
    
    @IBAction func motionTypeTapped() {
        if panoramaView.controlMethod == .touch {
            panoramaView.controlMethod = .motion
            indicator.titleLabel?.text = "Move Phone"
            let image = UIImage(named: "360_move.png")
            indicator.setImage(image, for: .normal)
        } else {
            panoramaView.controlMethod = .touch
            indicator.titleLabel?.text = "Grad Screen"
            let image = UIImage(named: "360_touch3.png")
            indicator.setImage(image, for: .normal)
        }
    }
    
    func loadSphericalImage(image: UIImage) {
        panoramaView.image = image
    }
    
    func loadCylindricalImage(image: UIImage) {
        panoramaView.image = image
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .all
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
