//
//  MapViewController.swift
//  avrio
//
//  Created by William Jattin on 2/13/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import CoreLocation
import WebKit

class MapViewController: UIViewController, UITextFieldDelegate, CLLocationManagerDelegate, MKMapViewDelegate, UINavigationBarDelegate ,WKNavigationDelegate, WKScriptMessageHandler, UISearchBarDelegate{
    var LocationManager = CLLocationManager()
    var SelectedAnnotation = MKAnnotation.self
    var isWebViewLoaded: Bool = false
    var isFirstLoad: Bool = false
    var CallBackText : String = ""
    var webV:WKWebView = WKWebView()
    var reloadMap : Bool = true
    var currentView = "Map";
    
    static var DevelopmentRequest:URLRequest = URLRequest(url: URL(fileURLWithPath: Bundle.main.path(forResource: "default/index", ofType: "html")!))
    
    var FeatureArray = [Dictionary<String,Any>]()

    override func viewWillAppear(_ animated: Bool) {
       
        super.viewWillAppear(animated)

        //Lets make a call
        if (!isFirstLoad) {
        print("here we co again")
        let parameters = ["urlToRequest":"https://api.zenonsoft.com/application/developments.php"]
        DataHelper.requestData(parameters)
            isFirstLoad = true
        }
        NotificationCenter.default.addObserver(self, selector: #selector(self.LoadFeatures), name: .gotData, object: nil)
        //NotificationCenter.default.addObserver(self, selector: #selector(self.LoadWebViews), name: .modelList, object: nil)
    
        
    }
    override func viewDidLoad() {
    //LoadListView()
        print("getting key")
        print("we will use this key: ")
        print(UIDevice.current.identifierForVendor?.uuidString)
        print(DataHelper.userKey())
        super.viewDidLoad()
        ToggleButton.title = "List View"
        
        //self.SliderPanel.contentSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height) //or ç
        self.SliderPanel.frame = self.view.frame
        
        //Create a webview to show the developments
        self.webV = WKWebView(frame: CGRect(x:0, y:0, width: self.SliderPanel.bounds.width, height: self.SliderPanel.bounds.height))
        self.webV.scrollView.bounces = false
        //self.webV.scalesToFit = true
        webV.frame.origin.x = CGFloat(0) //* self.SliderPanel.bounds.size.width
        webV.navigationDelegate = self
        self.webV.configuration.userContentController.add(self, name: "development")
        self.SliderPanel.addSubview(webV)
        let devURL = URL(string: "https://api.zenonsoft.com/application/views/all_developments.php?")
        let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
        self.webV.load(avrioURLRequest)
        // Initial Setup Stuff
        self.SliderPanel.isPagingEnabled = true
        self.SliderPanel.showsHorizontalScrollIndicator = false;
        //self.SliderPanel.isHidden = true
        self.HidePanel()
        // MapView Related
        MapView.delegate = self
        MapView.showsUserLocation = false
        MapView.userLocation.title = "CurrentLocation"
        
        //LocationManager Related
        LocationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        // Check for Location Services
        if (CLLocationManager.locationServicesEnabled()) {
            LocationManager.requestAlwaysAuthorization()
            LocationManager.requestWhenInUseAuthorization()
        } else {
            print("location not enabled")
        }
        
        
        //Zoom to user location
        if let userLocation = LocationManager.location?.coordinate {
            let viewRegion = MKCoordinateRegion(center: userLocation, latitudinalMeters: 1500, longitudinalMeters: 2000)
            self.MapView.setRegion(viewRegion, animated: true)
            
            let location = CLLocation(latitude: userLocation.latitude, longitude: userLocation.longitude) //changed!!!
            CLGeocoder().reverseGeocodeLocation(location, completionHandler: {(placemarks, error) -> Void in
                if error != nil {
                    print("got some error")
                    return
                } else if let country = placemarks?.first?.country,
                    let city = placemarks?.first?.locality,
                    let state = placemarks?.first?.administrativeArea
                     {
                    print(country)
                    print(city)
                    print(state)
                }
                else {
                    
                }
            })
            //self.mapView.centerCoordinate = userLocation
        }

        //End of initial setup
        //NotificationCenter.default.addObserver(self, selector: #selector(self.loadProperties), name: .propertyList, object: nil)
    }
    //Functions
    @objc func loadTimer(){
        print("timer loaded")
    }
    @objc func LoadFeatures() {
        print("removing annotations")
        self.MapView.removeAnnotations(self.MapView.annotations)
        DispatchQueue.global(qos: .userInitiated).async {
           // print(DataHelper.CAPTURED_DATA)
            print("loading features")
            var i = 0
            for response in DataHelper.CAPTURED_DATA  {
                //print(response.value(forKey:"num"))
                let re = response as! NSDictionary
                let Name = re.value(forKey: "name") as! String
                let tempCoverImage = re.value(forKey: "cover_image") as! NSArray
                let Address_1 = re.value(forKey: "address_1") as! String
                let Address_2 = re.value(forKey: "address_2") as! String
                let City = re.value(forKey: "city") as! String
                let State = re.value(forKey: "state") as! String
                let Zip = re.value(forKey: "zip") as! String
                let num = re.value(forKey: "num") as! String
                let lat = re.value(forKey: "lat") as! String
                let lon = re.value(forKey: "lon") as! String
                let FullAddress = Address_1 + " " + Address_2 + ", " + City + ", " + State + ", " + Zip
                self.LoadMap(location: FullAddress, order: i, details: re, mapArea: self.MapView, lat : lat, lon: lon, num: num)
                i += 1
                var coverImage = "https://api.zenonsoft.com" as String
                let tempImg = (tempCoverImage[0] as AnyObject).value(forKey: "thumbUrlPath2") as! String
                coverImage.append(tempImg)
                print("==========================")
                let tempArray = ["name" : Name, "image": coverImage, "details" : re, "num" : num ] as [String : Any]
                self.FeatureArray.append(tempArray)
            }
            //print(self.FeatureArray)
            // Bounce back to the main thread to update the UI
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                //self.LoadWebViews()

            }
        }
    }
    //We can load all pages at once but this gets intensive if we have too many so we'll use the LoadWebView Instead to create a web view in the slidercontainer (Just 1 slide for now)
   @objc func LoadWebViews(){
        self.SliderPanel.contentSize = CGSize(width: self.view.bounds.width * CGFloat(self.FeatureArray.count) , height: 250) //or self.view.bounds.height
        for (index,feature) in FeatureArray.enumerated() {
            let webV:WKWebView = WKWebView(frame: CGRect(x:0, y:0, width: SliderPanel.bounds.width, height:SliderPanel.bounds.height + 60))
            webV.frame.origin.x = CGFloat(index) * self.SliderPanel.bounds.size.width

            webV.navigationDelegate = self
            // Get The development NUM
            let num =  feature["num"] as? String
            
            let devURL = URL(string: "https://api.zenonsoft.com/application/views/development_details.php?num=" + num! )
            let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
            webV.load(avrioURLRequest)
            webV.configuration.userContentController.add(self, name: "jsHandler")
            webV.configuration.userContentController.add(self, name: "model")

            self.SliderPanel.addSubview(webV)
                    }
        
    }

   func LoadListView(){
            let webV:WKWebView = WKWebView(frame: CGRect(x:0, y:0, width: SliderPanel.bounds.width, height:SliderPanel.bounds.height + 60))
            webV.frame.origin.x = self.SliderPanel.bounds.size.width
            
            webV.navigationDelegate = self
            // Get The development NUM
            
            let devURL = URL(string: "https://api.zenonsoft.com/application/views/development_details.php")
            let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
            webV.load(avrioURLRequest)
            webV.configuration.userContentController.add(self, name: "jsHandler")
            webV.configuration.userContentController.add(self, name: "model")
            
            self.SliderPanel.addSubview(webV)
       self.SliderPanel.isHidden = false
        
    }
    
    func LoadWebView(devId: String){
        // Get The development NUM
        let devURL = URL(string: "https://api.zenonsoft.com/application/views/development_details.php?num=" + devId )
            let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
            self.webV.load(avrioURLRequest)

    }

    func UpdateScroll(){
        self.SliderPanel.contentSize = CGSize(width: self.view.bounds.width * CGFloat(self.FeatureArray.count) , height: 250) //or self.view.bounds.height
        for (index,feature) in FeatureArray.enumerated() {
            if let FeatureView = Bundle.main.loadNibNamed("FeatureView", owner: self, options: nil)?.first as? FeatureContainer {
                //featureView.previewImage.image = UIImage(named: feature["image"]!
                FeatureView.coverImage.image = UIImage(named: feature["image"]! as! String)
                FeatureView.coverImage.image = DataHelper.loadImage(imageUrl: feature["image"]! as! String)
                FeatureView.name.text = feature["name"] as? String
                let FeatureDetails = feature["details"] as! NSDictionary
                if(FeatureDetails.value(forKey: "models_count") as! Int == 0) {
                        FeatureView.models.isHidden = true
                    }
                if(FeatureDetails.value(forKey: "property_count") as! Int  == 0) {
                    FeatureView.properties.isHidden = true
                }
                FeatureView.DevelopmentID = FeatureDetails.value(forKey: "num") as! String
                FeatureView.details.text = FeatureDetails.value(forKey: "content") as? String
                
                FeatureView.frame.size.width = self.SliderPanel.bounds.size.width
                FeatureView.frame.size.height = self.SliderPanel.bounds.size.height
                FeatureView.frame.origin.x = CGFloat(index) * self.SliderPanel.bounds.size.width
                self.SliderPanel.addSubview(FeatureView)
            }
            //SliderPanel.contentOffset.x = 2 * self.view.bounds.size.width
        }
        
        //self.loadFeatures()
    }
    

    func dosom() -> Void {
        
    }
    @objc func loadModels() -> Void {
        print("models clicked")
        self.performSegue(withIdentifier: "detailsloader", sender: nil)
        
        //NotificationCenter.default.
        //self.present(newViewController, animated: true, completion: nil)
    }
    

     func loadProperties() -> Void {
        print("properties clicked")
    }
    
    func ShowPanel(){
        
        title = self.currentView
        UIView.animate(withDuration: 0.45, animations:{ () -> Void in
            self.SliderPanel.isHidden = false
             self.view.layoutIfNeeded()
            
        })
    }
    //end ShowPanel
    func HidePanel(){
        title = self.currentView
        self.SliderPanel.isHidden = true
//        UIView.animate(withDuration: 0.45, animations:{ () -> Void in
//            self.SliderPanelBottom.constant = -1080
//            self.SliderPanelTop.constant = 1080
//            self.view.layoutIfNeeded()
//            self.MapView.updateFocusIfNeeded()
//            self.MapView.reloadInputViews()
//            self.SliderTitleTop.constant  = -60
//        })
        // TODO: deselect annotations
    }
    //end HidePanel
    @IBOutlet weak var ToggleButton: UIBarButtonItem!
    
    @IBAction func ToggleView(_ sender: Any) {
        print(self.currentView)
        if(self.currentView == "Map") {
            self.ToggleButton.title = "Map View"
            self.currentView = "List"
            self.searchButton.isEnabled = false
            self.ShowPanel()
        } else {
            self.ToggleButton.title = "List"
            self.currentView = "Map"
            self.searchButton.isEnabled = true
            self.HidePanel()
        }
    }
    //Outlets
    @IBOutlet var MapView: MKMapView!
    @IBOutlet weak var SliderPanel: UIScrollView!

    @IBOutlet weak var DevelopmentToggle: WKWebView!
    
    @IBAction func searchButton(_ sender: Any){
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        searchController.searchBar.placeholder = "Address, City, State or Zip Code"
        present(searchController, animated: true, completion: nil)
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        // ignoring user
        UIApplication.shared.beginIgnoringInteractionEvents()
        // Activity Indicator
        let activityIndicator = UIActivityIndicatorView()
        activityIndicator.style = UIActivityIndicatorView.Style.gray
        activityIndicator.center = self.view.center
        activityIndicator.hidesWhenStopped = true
        activityIndicator.startAnimating()
        
        self.view.addSubview(activityIndicator)
        
        //hide search bar
        
        searchBar.resignFirstResponder()
        dismiss(animated: true, completion: nil)
        
        // create the search request
        let searchRequesst = MKLocalSearch.Request()
        searchRequesst.naturalLanguageQuery = searchBar.text
        
        let activeSearch = MKLocalSearch(request: searchRequesst)
        
        activeSearch.start { (response,error) in
            if response == nil {
                print("error")
            }
            else {
                // remove annotations first (no?)
                activityIndicator.stopAnimating()
                UIApplication.shared.endIgnoringInteractionEvents()
                
                //let annotations = self.MapView.annotations
                
                
                // get the data
                let latitude = response?.boundingRegion.center.latitude
                let longitude = response?.boundingRegion.center.longitude
                
                //create annotation
                
//                let annotation = MKPointAnnotation()
//                annotation.title = searchBar.text
//                annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
//                self.MapView.addAnnotation(annotation)
                
                //zoom in
                let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                let span = MKCoordinateSpan(latitudeDelta: 0.5,longitudeDelta: 0.5)
                let region = MKCoordinateRegion(center: coordinate,span: span)
                self.MapView.setRegion(region, animated: true)
                

                
            }
        }
        
    }
    @IBAction func MapPinchGesture(_ sender: Any) {
        print("pinching")
    }
    @IBAction func ButtonCloseSliderPanel(_ sender: Any) {
        self.HidePanel()
    }
    @IBAction func FeatureSwipeUp(recognizer: UISwipeGestureRecognizer) {
       // self.HidePanel()
    }

    @IBOutlet weak var searchButton: UIBarButtonItem!
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webView.title

    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
      
        switch message.name { case "development":
            print(message.name)
            print(message.body)
            let num : NSNumber  = message.body as! NSNumber
            DataHelper.CURRENT_VIEW["num"] = num.stringValue
            let myURL = URL(string:"https://api.zenonsoft.com/application/views/development_details.php?num=" + num.stringValue )
            MapViewController.DevelopmentRequest = URLRequest(url: myURL!)
            self.performSegue(withIdentifier: "developmentdetails", sender: Any?.self)
            //self.CallBackText = message.body as! String
            case "model" :
                DataHelper.CURRENT_VIEW["view"] = "model"
                DataHelper.CURRENT_VIEW["modelnum"] = message.body as! Int
                self.loadModels()
            default:
           break
        }
        
    }

/****************************************
*****************************************
** ALL MAP RELATED FUNCTIONS
*****************************************
******************************************/
    //Annotation view with text
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        let reuseId = "reuseid"
        var av = mapView.dequeueReusableAnnotationView(withIdentifier: reuseId)
        if av == nil {
            av = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            let lbl = UILabel(frame: CGRect(x: 0, y: 0, width: 60, height: 20))
            lbl.backgroundColor = .red
            lbl.textColor = .white
            //lbl.alpha = 0.5
            lbl.tag = 42
            //lbl.frame.size
            av?.addSubview(lbl)
            av?.canShowCallout = true
            av?.frame = lbl.frame
        }
        else {
            av?.annotation = annotation
        }
        let annotationDetails = annotation as! Annotation
        let lbl = av?.viewWithTag(42) as! UILabel
        lbl.text = annotationDetails.title
        lbl.textAlignment = .center
        lbl.font = UIFont.systemFont(ofSize: 10.0)
        return av
    }
    func LoadMap(location: String, order: Int, details: NSDictionary, mapArea: MKMapView,lat: String, lon: String, num : String ) -> Void {
        print("inside loadmap")
        var placemark: CLPlacemark!
        let annotation = Annotation()
        if(lat == "N") {
        CLGeocoder().geocodeAddressString(location, completionHandler: {(placemarks, error)->Void in
            if error == nil {
                placemark = placemarks![0] as CLPlacemark
                annotation.coordinate = CLLocationCoordinate2D(latitude: placemark.location!.coordinate.latitude, longitude: placemark.location!.coordinate.longitude)
                let userPoint = MKMapPoint(self.MapView.userLocation.coordinate)
                
                    let tlat = String(annotation.coordinate.latitude)
                    let tlon = String(annotation.coordinate.longitude)
                    let geoCode = URL(string: "https://api.zenonsoft.com/application/geocode.php?num=" + num + "&lat=" + tlat + "&lon=" + tlon )
                   var UpdateGeo : URLRequest = URLRequest(url: geoCode!)
                    UpdateGeo.httpMethod = "GET"
                     let session4 = URLSession.shared
                        let task = session4.dataTask(with: UpdateGeo as URLRequest) { (data, response, error) in
                        guard let _: Data = data, let _: URLResponse = response, error == nil else {
                            print("*****error")
                            return
                        }
                    }
                    task.resume()
                
               
            }
        })
        } else {
            annotation.coordinate.latitude = Double(lat)!
            annotation.coordinate.longitude = Double(lon)!
        }
//        print(annotation.coordinate.latitude)
//        print(annotation.coordinate.longitude)
        //inside = mapArea.visibleMapRect.contains(MKMapPoint(annotation.coordinate))

            // var inside = mapArea.visibleMapRect.contains(MKMapPoint(userPoint.coordinate))
            annotation.title = "From: " +  ((details.value(forKey: "starting_price") as? String)!)
            //annotation.subtitle = "Sub Title " + location
            annotation.FeatureId = order
            annotation.DevelopmentId = details.value(forKey: "num") as! String
            print("adding annotation")
            self.MapView.addAnnotation(annotation)
    }
    //end LoadMap
    //Function to add actions to the pin when touched
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {

        let selectedLocation = view.annotation?.title
        if let SliderOrder = view.annotation as? Annotation
        {

           // self.LoadWebView(devId: SliderOrder.DevelopmentId)
            if(selectedLocation != "CurrentLocation")
            {
                //self.ShowPanel()
                DataHelper.CURRENT_VIEW["num"] = SliderOrder.DevelopmentId
                let myURL = URL(string:"https://api.zenonsoft.com/application/views/development_details.php?num=" + SliderOrder.DevelopmentId )
                MapViewController.DevelopmentRequest = URLRequest(url: myURL!)
                self.performSegue(withIdentifier: "developmentdetails", sender: Any?.self)
                
            }
           // self.SliderPanel.contentOffset.x = CGFloat(SliderOrder.FeatureId) * self.SliderPanel.bounds.size.width
        }
        MapView.deselectAnnotation(view.annotation, animated: false)
      
    }
    // Reload data if map moves
    func mapViewDidChangeVisibleRegion(_ mapView: MKMapView) {
       
       // self.LoadFeatures()
      
        
    }
    func mapViewDidFinishRenderingMap(_ mapView: MKMapView,
                                      fullyRendered: Bool) {
        print("finished rendering map")
    }

    //    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    //        if annotation is MKUserLocation {
    //            return nil
    //        }
    //        var annotationView = MKMarkerAnnotationView()
    //        guard let annotation = annotation as? MKAnnotation else {return nil}
    //        let identifier = "grouper"
    //        var color = UIColor.red
    //
    //        if(annotation.title == "CurrentLocation") {
    //            color = UIColor.blue
    //        }
    //        if let dequedView = mapView.dequeueReusableAnnotationView(
    //            withIdentifier: identifier)
    //            as? MKMarkerAnnotationView {
    //            annotationView = dequedView
    //
    //
    //        } else{
    //            annotationView = MKMarkerAnnotationView(annotation: annotation, reuseIdentifier: identifier)
    //            let lbl = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 30))
    //            lbl.backgroundColor = .black
    //            lbl.textColor = .white
    //            lbl.alpha = 0.5
    //            lbl.tag = 42
    //            annotationView.addSubview(lbl)
    //            annotationView.canShowCallout = true
    //            annotationView.frame = lbl.frame
    //        }
    //        let lbl = annotationView.viewWithTag(42) as! UILabel
    //        lbl.text = annotation.title!
    //        //annotationView.glyphText = annotation.title as? String
    ////        annotationView.backgroundColor = UIColor.white
    ////        annotationView.markerTintColor = color
    ////        //annotationView.glyphImage = UIImage(named: "pizza")
    ////        annotationView.glyphTintColor = .white
    //        annotationView.clusteringIdentifier = identifier
    //        return annotationView
    //    }
    
    // end annotation view with pin
    
    //    //Function to update the pin and title.. used just for debugging
    //    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
    //        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "AnnotationView")
    //        if(annotationView == nil)
    //        {
    //            annotationView = MKAnnotationView( annotation: annotation, reuseIdentifier: "AnnotationView")
    //        }
    //        annotationView?.image = UIImage(named: "home-icon")
    //        // To show the title and subtile are shown in a box instead of below the annotation
    //        annotationView?.canShowCallout = false
    //        return annotationView
    //    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
/***************************************
****************************************
** SEGUES
****************************************/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "detailsloader" {

        }
    }

}
