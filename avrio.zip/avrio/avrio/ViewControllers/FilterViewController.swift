//
//  FilterViewController.swift
//  avrio
//
//  Created by William Jattin on 3/18/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import Foundation
import UIKit
import WebKit


class FilterViewController: UIViewController {
    
    let currencyFormatter = NumberFormatter()
    let valuesFormatter = NumberFormatter()
    let bedrooms = ["no min","1+","2+","3+","4+","5+"]
    let bathrooms = ["no min","1+","2+","3+","4+"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currencyFormatter.usesGroupingSeparator = true
        valuesFormatter.usesGroupingSeparator = true
        valuesFormatter.numberStyle = .decimal
        currencyFormatter.numberStyle = .currency
        // localize to your grouping and decimal separator
        currencyFormatter.locale = Locale.current
        BedsMin.setWidth(CGFloat((self.view.frame.width - 35)/6), forSegmentAt: 0)
        BedsMin.setWidth(CGFloat((self.view.frame.width - 41)/6), forSegmentAt: 1)
        BedsMin.setWidth(CGFloat((self.view.frame.width - 41)/6), forSegmentAt: 2)
        BedsMin.setWidth(CGFloat((self.view.frame.width - 41)/6), forSegmentAt: 3)
        BedsMin.setWidth(CGFloat((self.view.frame.width - 41)/6), forSegmentAt: 4)
        BedsMin.setWidth(CGFloat((self.view.frame.width - 41)/6), forSegmentAt: 5)
        //add options to bedrooms segment
        for bed in bedrooms {
            BedsMin.setTitle(bed, forSegmentAt: bedrooms.index(of: bed)!)
        }
        //see if the search has min bedrooms specified and select if on our form
        if(DataHelper.SEARCH.index(forKey: "bedrooms_min") != nil) {
            BedsMin.selectedSegmentIndex = Int(DataHelper.SEARCH["bedrooms_min"]!)!
        }
        //add options to bathroom segment
        for baths in bathrooms {
            BathsMin.setTitle(baths, forSegmentAt: bathrooms.index(of: baths)!)
        }
        //see if the search has min bedrooms specified and select if on our form
        if(DataHelper.SEARCH.index(forKey: "bathrooms_min") != nil) {
            BathsMin.selectedSegmentIndex = Int(DataHelper.SEARCH["bathrooms_min"]!)!
        }
        //see if we have a sq ft filter
        if(DataHelper.SEARCH.index(forKey: "sq_ft_max_min") != nil) {
            //BathsMin.selectedSegmentIndex = Int(DataHelper.SEARCH["sq_ft_max_min"]!)!
            let labelvalue  =  (DataHelper.SEARCH["sq_ft_max_min"]! as NSString).intValue
            let slidervalue  =  (DataHelper.SEARCH["sq_ft_max_min"]! as NSString).floatValue
            //SqFtMin.self.
            SqFtMin.setValue(slidervalue, animated: true)
            let roundedValue = round(slidervalue / step) * step
            let value  = Int(roundedValue) as NSNumber
            
            MinSqFtLabel.text = "Min. Sq. Ft: " + valuesFormatter.string(from: value)!

        }
        if(DataHelper.SEARCH.index(forKey: "ending_price_max") != nil) {
            //BathsMin.selectedSegmentIndex = Int(DataHelper.SEARCH["sq_ft_max_min"]!)!
            let labelvalue  =  (DataHelper.SEARCH["ending_price_max"]! as NSString).intValue
            let slidervalue  =  (DataHelper.SEARCH["ending_price_max"]! as NSString).floatValue
            //SqFtMin.self.
            MaxPrice.setValue(slidervalue, animated: true)
            let roundedValue = round(slidervalue / step) * step
            let value  = Int(roundedValue) as NSNumber
            
            MaxPriceLabel.text = "Max. Price: $" + valuesFormatter.string(from: value)!

        }
        


    }
    @IBAction func UpdateFilters(_ sender: Any) {
        _ = navigationController?.popToRootViewController(animated: true)
    }
    @IBOutlet weak var LocLabel: UILabel!
    

    @IBAction func BedsMin(_ sender: Any) {
        switch BedsMin.selectedSegmentIndex {
        case 0:
        DataHelper.SEARCH.removeValue(forKey: "min_bedrooms_query")
        DataHelper.SEARCH.removeValue(forKey: "bedrooms_min")
        break
        default:
            DataHelper.SEARCH["min_bedrooms_query"] =  String(BedsMin.selectedSegmentIndex)
            DataHelper.SEARCH["bedrooms_min"] =  String(BedsMin.selectedSegmentIndex)
        }
        
        self.filteredResults(filters: DataHelper.SEARCH)
    }
    @IBOutlet weak var BathsMin: UISegmentedControl!
    @IBOutlet weak var BedsMin: UISegmentedControl!
    @IBOutlet weak var MinSqFtLabel: UILabel!
    @IBOutlet weak var MaxPriceLabel: UILabel!
    @IBOutlet weak var SqFtMin: UISlider!
    @IBOutlet weak var MaxPrice: UISlider!

    
    @IBAction func BathsMin(_ sender: Any) {
        switch BathsMin.selectedSegmentIndex {
        case 0:
            DataHelper.SEARCH.removeValue(forKey: "min_bathrooms_query")
            DataHelper.SEARCH.removeValue(forKey: "bathrooms_min")
            break
        default:
            DataHelper.SEARCH["min_bathrooms_query"] =  String(BathsMin.selectedSegmentIndex)
            DataHelper.SEARCH["bathrooms_min"] =  String(BathsMin.selectedSegmentIndex)
        }
        self.filteredResults(filters: DataHelper.SEARCH)
    }
    let step: Float = 2500
    
    @IBAction func MaxPrice(sender:UISlider) {
        let roundedValue = round(sender.value / step) * step
        sender.value = roundedValue
        let value  = Int(roundedValue) as NSNumber
        MaxPriceLabel.text = "Max. Price: $" + valuesFormatter.string(from: value)!
        DataHelper.SEARCH["ending_price_max"] =  String(roundedValue)
        self.filteredResults(filters: DataHelper.SEARCH)
        print(DataHelper.SEARCH)
    }
    
    @IBAction func SqFtMin(sender:UISlider) {
        let roundedValue = round(sender.value / step) * step
        sender.value = roundedValue
        let value  = Int(roundedValue) as NSNumber
        MinSqFtLabel.text = "Min. Sq. Ft: " + valuesFormatter.string(from: value)!
        DataHelper.SEARCH["sq_ft_max_min"] =  String(roundedValue)
        self.filteredResults(filters: DataHelper.SEARCH)
        print(DataHelper.SEARCH)
    }
    
    @IBAction func SqFtMax(_ sender: Any) {
    }
    @IBAction func PriceMin(_ sender: Any) {
    }
    @IBAction func PriceMax(_ sender: Any) {
        let price = PiceMaxValue!.value as NSNumber
        let priceString = currencyFormatter.string(from: price)!
        //print(PiceMaxValue.value)
        PriceMaxLabel.text = "max: " + priceString
    }
    
    @IBOutlet weak var PiceMaxValue: UISlider!
    
    @IBOutlet weak var PriceMaxLabel: UILabel!
    func sliderValueDidChange(sender:UISlider!)
    {
        //Set value to the nearest 5...
        print((Float)((Int)((sender.value + 2.5) / 1000) * 1000))
        sender.setValue((Float)((Int)((sender.value + 2.5) / 1000) * 1000), animated: false)
    }
    func filteredResults(filters: [String:String]) {
         var queryString : String = "?query=1"
        for filter in filters {
            if filter.value != "" {
            queryString += "&" + filter.key + "=" + filter.value
            }
        }
        print ("https://api.zenonsoft.com/application/developments.php" + queryString)
        let parameters = ["urlToRequest":"https://api.zenonsoft.com/application/developments.php" + queryString]
        DataHelper.requestData(parameters)
    }
    
}
