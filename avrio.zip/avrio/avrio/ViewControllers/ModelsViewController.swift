//
//  ModelsViewController.swift
//  avrio
//
//  Created by William Jattin on 2/21/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit

class ModelsViewController: UIViewController ,UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var ModelsTable: UITableView!
    @IBOutlet weak var LoadingIndicator: UIActivityIndicatorView!
    var HaveData = false;
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    override func viewDidLoad() {
        super.viewDidLoad()
        self.ModelsTable.isHidden = true;
        self.LoadingIndicator.isHidden = false;
        //self.ModelsTable.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.ModelsTable.register(ModelsListViewCellTableViewCell.self, forCellReuseIdentifier: "Cell")
        //self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        self.ModelsTable.rowHeight = UITableView.automaticDimension
        self.ModelsTable.estimatedRowHeight = 340
        self.ModelsTable.separatorStyle = .none
        
        print("models table loaded")
        let DevelopmentId = DataHelper.CURRENT_VIEW["num"] as! String
        //Lets make a call
        let parameters = ["urlToRequest":"https://api.zenonsoft.com/application/models.php?development="+DevelopmentId,
                          "view":"models"]
        DataHelper.requestData(parameters)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.LoadModels), name: .gotModels, object: nil)
    
    }
    @objc func LoadModels() {
        DispatchQueue.global(qos: .userInitiated).async {
            print("notification received")
            // print(DataHelper.CAPTURED_DATA)
            var i = 0
            for response in DataHelper.CAPTURED_DATA  {
                //print(response.value(forKey:"num"))
                let re = response as! NSDictionary
               // let Name = re.value(forKey: "name") as! String

                 i = i+1

               // let tempArray = ["name" : Name, "image": coverImage, "details" : re ] as [String : Any]
                //self.FeatureArray.append(tempArray)
            }
         
            // Bounce back to the main thread to update the UI
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                //self.UpdateScroll()
                print("OK all data is ready to update the view ")
                /* Table operations*/

                /* End Table operations*/
                self.HaveData = true;
                self.ModelsTable.reloadData()
                self.ModelsTable.isHidden = false;
                self.LoadingIndicator.isHidden = true;
                
            }
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("inside tableview")
        print(DataHelper.CAPTURED_DATA.count)
        return DataHelper.CAPTURED_DATA.count;
    }
    // Set the content for each table view
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)  as! ModelsListViewCellTableViewCell
        
       // let cell:ModelsListViewCellTableViewCell = self.ModelsTable.dequeueReusableCell(withIdentifier: "cell")! as! ModelsListViewCellTableViewCell
        if(self.HaveData) {
        print("adding models")
       let ModelInfo = DataHelper.CAPTURED_DATA[indexPath.row] as! NSDictionary
            
            let ModelImages = ModelInfo.value(forKey: "model_images") as! NSArray
            print("ModelImages.count")
            if ModelImages.count > 0 {
                let TempImg = ModelImages[0] as! NSDictionary
                let MainImage = TempImg.value(forKey: "thumbUrlPath") as! String
                let ImageLink = "https://api.zenonsoft.com/" + MainImage
                cell.ModelImage?.downloadedFrom(link: ImageLink)
            }

           
            
            //print(ModelInfo)
            //
            
            cell.ModelPrice?.text = ModelInfo.value(forKey: "name") as? String
            cell.ModelSummary?.text = ModelInfo.value(forKey: "name") as? String

            

        //cell.textLabel?.text = ModelInfo.value(forKey: "name") as! String
     //   cell.textLabel?.font = UIFont(name: "HelveticaNeue-CondensedBold", size: 20)
      //  cell.textLabel?.textColor = UIColor(red:0, green:0.392, blue:0,alpha:1.0)
        }
            return cell
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension UIImageView {
    func downloadedFrom(url: URL, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        contentMode = mode
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard
                let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200,
                let mimeType = response?.mimeType, mimeType.hasPrefix("image"),
                let data = data, error == nil,
                let image = UIImage(data: data)
                else { return }
            DispatchQueue.main.async() {
                self.image = image
            }
            }.resume()
    }
    func downloadedFrom(link: String, contentMode mode: UIView.ContentMode = .scaleAspectFit) {
        guard let url = URL(string: link) else { return }
        downloadedFrom(url: url, contentMode: mode)
    }
}
