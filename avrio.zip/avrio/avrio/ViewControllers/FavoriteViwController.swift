//
//  FavoriteViwController.swift
//  avrio
//
//  Created by William Jattin on 4/3/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit
import WebKit

class FavoriteViwController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {
    @IBOutlet weak var FavoriveWB: WKWebView!
    let uid = String(UIDevice.current.identifierForVendor!.uuidString)
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
       FavoriveWB.navigationDelegate = self
        FavoriveWB.frame = CGRect(x:0, y:0, width: self.view.bounds.width, height: self.view.bounds.height )
        FavoriveWB.scrollView.bounces = false
        FavoriveWB.allowsBackForwardNavigationGestures = true
        let myURL = URL(string:"https://api.zenonsoft.com/application/views/favorite_models.php?uid=" + uid )
        let myRequest = URLRequest(url: myURL!)
        self.FavoriveWB.load(myRequest);
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        FavoriveWB.configuration.userContentController.add(self, name: "jsHandler")
        FavoriveWB.configuration.userContentController.add(self, name: "model")
        FavoriveWB.configuration.userContentController.add(self, name: "models")

    }
    
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
      //  title = WebView.title
       // loader.isHidden = true
        
    }
    @objc func loadModels() -> Void {
        print("models clicked")
        self.performSegue(withIdentifier: "details", sender: nil)
        
        //NotificationCenter.default.
        //self.present(newViewController, animated: true, completion: nil)
    }
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        
        switch message.name { case "jsHandler":
            print(message.name)
            print(message.body)
            //self.CallBackText = message.body as! String
            
            
        case "model" :
            DataHelper.CURRENT_VIEW["view"] = "model"
            DataHelper.CURRENT_VIEW["modelnum"] = message.body as! Int
            self.loadModels()
            print(message.name)
            print(message.body)
        case "models" :
            //DataHelper.CURRENT_VIEW["view"] = "model"
            //DataHelper.CURRENT_VIEW["modelnum"] = message.body as! Int
            //self.loadModels()
            let models : NSDictionary = message.body as! NSDictionary
            //print(models.value(forKey: "models"))
            
            let modelIds: NSArray = models.value(forKey: "models") as! NSArray
            
            for model in modelIds {
                print("inside loop")
                print(model)
                let modelString = model as! String
                let modelInt = Int(modelString)
                let devURL = URL(string: "https://api.zenonsoft.com/application/views/model_details.php?num=" + modelString + "&uid=" + uid)
                print(devURL)
                
                
                
                let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
                DevelopmentsViewController.Models.updateValue(avrioURLRequest, forKey: modelInt!)
                print(model as! String)
                print("done with models")
                
            }
            print(message.name)
            print(message.body)
            
            
        default:
            break
        }
        
    }
}
