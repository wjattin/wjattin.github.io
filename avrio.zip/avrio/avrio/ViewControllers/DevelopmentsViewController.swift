//
//  DevelopmentsViewController.swift
//  avrio
//
//  Created by William Jattin on 2/28/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit
import WebKit

class DevelopmentsViewController: UIViewController, WKNavigationDelegate, WKScriptMessageHandler {
    let uid = String(UIDevice.current.identifierForVendor!.uuidString)
    static var lastId: String = ""
    // an array of requests
    static var Models = [Int:URLRequest]() //as NSDictionary

    @IBOutlet weak var WebView: WKWebView!
    
    @IBOutlet weak var loader: UIActivityIndicatorView!
    override func loadView() {
        super.loadView()
       
}
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loader.startAnimating()
        WebView.navigationDelegate = self
        WebView.frame = CGRect(x:0, y:0, width: self.view.bounds.width, height: self.view.bounds.height )
        //WebView = WKWebView(frame: CGRect(x:0, y:0, width: self.view.bounds.width, height: self.view.bounds.height - 120 ))
        WebView.scrollView.bounces = false
        //self.webV.scalesToFit = true

        
        
        WebView.allowsBackForwardNavigationGestures = true

    }
    override func viewDidLoad() {
        super.viewDidLoad()
        loader.isHidden = false
        let DevelopmentId = DataHelper.CURRENT_VIEW["num"] as! String
        let myURL = URL(string:"https://api.zenonsoft.com/application/views/development_details.php?num=" + DevelopmentId + "&uid=" + uid )
        let myRequest = URLRequest(url: myURL!)
        self.WebView.load(myRequest)
        //self.WebView.load(MapViewController.DevelopmentRequest)
        WebView.configuration.userContentController.add(self, name: "jsHandler")
        WebView.configuration.userContentController.add(self, name: "model")
        WebView.configuration.userContentController.add(self, name: "models")
    }
    
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        
        switch message.name { case "jsHandler":
            print(message.name)
            print(message.body)
            //self.CallBackText = message.body as! String
            
            
        case "model" :
            DataHelper.CURRENT_VIEW["view"] = "model"
            DataHelper.CURRENT_VIEW["modelnum"] = message.body as! Int
            self.loadModels()
            print(message.name)
            print(message.body)
        case "models" :
            //DataHelper.CURRENT_VIEW["view"] = "model"
            //DataHelper.CURRENT_VIEW["modelnum"] = message.body as! Int
            //self.loadModels()
            let models : NSDictionary = message.body as! NSDictionary
            //print(models.value(forKey: "models"))

            let modelIds: NSArray = models.value(forKey: "models") as! NSArray
            
            for model in modelIds {
                print("inside loop")
                print(model)
                let modelString = model as! String
            let modelInt = Int(modelString)
            let devURL = URL(string: "https://api.zenonsoft.com/application/views/model_details.php?num=" + modelString + "&uid=" + uid)
                print(devURL)



           let avrioURLRequest:URLRequest = URLRequest(url: devURL!)
                DevelopmentsViewController.Models.updateValue(avrioURLRequest, forKey: modelInt!)
                print(model as! String)
                print("done with models")

            }
           print(message.name)
           print(message.body)
            
            
        default:
            break
        }
        
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = WebView.title
        loader.isHidden = true
        
    }

    @objc func loadModels() -> Void {
        print("models clicked")
        self.performSegue(withIdentifier: "details", sender: nil)
        
        //NotificationCenter.default.
        //self.present(newViewController, animated: true, completion: nil)
    }
}
