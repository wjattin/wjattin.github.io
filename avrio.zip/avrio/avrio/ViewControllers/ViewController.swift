//
//  ViewController.swift
//  avrio
//
//  Created by William Jattin on 2/13/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//
import Foundation
import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        
    }


}

