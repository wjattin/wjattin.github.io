//
//  GalleryViewController.swift
//  avrio
//
//  Created by William Jattin on 3/5/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import Foundation
import UIKit

class GalleryViewController : UIViewController {
    
    static var SelectedImage: Int = 0
    
    private let _reuseIdentifier = "thumbContainer"
    private let sectionInsets = UIEdgeInsets(top: 50.0,
                                             left: 20.0,
                                             bottom: 50.0,
                                             right: 20.0)
    private let itemsPerRow: CGFloat = 1
    
    static var FullScreenImages = [UIImage]()
    
    
    @IBOutlet weak var GalleryContainer: UICollectionView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        GalleryViewController.FullScreenImages.removeAll()
        
        self.GalleryContainer.minimumZoomScale = 1.0
        self.GalleryContainer.maximumZoomScale = 6.0
        self.GalleryContainer.frame = self.view.frame
        self.GalleryContainer.delegate = self
        switch DetailsViewController.GalleryType
        {
        case "tour":
        self.title = "360 Tour"
        case "plans":
        self.title = "Floor Plans"
        default:
        self.title = "Gallery"
        }
        
        print("DetailsViewController.GalleryType")
        print(DetailsViewController.GalleryType)
       // print(DetailsViewController.GalleryImages)
        print("DetailsViewController.CurrentImage")
        print(DetailsViewController.CurrentImage)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        if let flowLayout = self.GalleryContainer.collectionViewLayout as? UICollectionViewFlowLayout {
            flowLayout.itemSize = CGSize(width: self.GalleryContainer.bounds.width, height: 120)
        }
    }
}
private extension GalleryViewController {
    func photo(for indexPath: IndexPath) -> NSDictionary {
        return DetailsViewController.GalleryImages[indexPath.row] as! NSDictionary
    }
}
extension GalleryViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print(DetailsViewController.GalleryType)
        if(DetailsViewController.GalleryType == "tour") {
            GalleryViewController.SelectedImage = indexPath.row
            performSegue(withIdentifier: "fullscreen", sender: Any?.self)
        }
        else {
            GalleryViewController.SelectedImage = indexPath.row
            performSegue(withIdentifier: "galleryZoom", sender: Any?.self)
        }
        
    }
}

extension GalleryViewController {
    
    func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath
        ) -> UICollectionViewCell {
        //1
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: _reuseIdentifier,
                                                      for: indexPath) as! GalleryPhotoCell
        //2
        let Galleryimage = photo(for: indexPath)
        print("Galleryimage " )
        print(indexPath.row)
//        print(Galleryimage)
        //cell.backgroundColor = .black
        //3
        let info1: String = (DetailsViewController.GalleryImages[indexPath.row] as AnyObject).value(forKey: "info1")! as! String
        print("info1 " + info1)
        cell.label.text = info1
        let thumbUrlPath = "https://api.zenonsoft.com" + String(Galleryimage.value(forKey: "thumbUrlPath")! as! String)
        print()
        // Let pre render the large image and add them to our array so it's ready to load full screen
        let urlPath = "https://api.zenonsoft.com" + String(Galleryimage.value(forKey: "urlPath")! as! String)
        
        let tempFullScreen : UIImage = DataHelper.loadImage(imageUrl: urlPath)
        GalleryViewController.FullScreenImages.append(tempFullScreen)
        cell.thumbnail.image = DataHelper.loadImage(imageUrl: thumbUrlPath)
        
        return cell
    }
}
extension GalleryViewController: UICollectionViewDataSource {
    //1
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        //2
        let paddingSpace = sectionInsets.left * (itemsPerRow + 1)
        let availableWidth = GalleryContainer.frame.width - paddingSpace
        let widthPerItem = availableWidth / itemsPerRow
        print("inside collection datasource")
        return CGSize(width: widthPerItem, height: widthPerItem)
    }
}
extension GalleryViewController : UICollectionViewDelegateFlowLayout {
  
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return DetailsViewController.GalleryImages.count
    }
    //3
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        insetForSectionAt section: Int) -> UIEdgeInsets {
        return self.sectionInsets
    }
    
    // 4
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return self.sectionInsets.left
    }
}
