//
//  DetailsViewController.swift
//  avrio
//
//  Created by William Jattin on 3/2/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit
import WebKit

class DetailsViewController: UIViewController, WKNavigationDelegate,WKScriptMessageHandler {
    
    static var GalleryFloorPlanImages = NSArray()
    static var GalleryTourImages = NSArray()
    static var GalleryImages = NSArray()
    static var GalleryType = String()
    static var CurrentImage : Int = 0

    @IBOutlet weak var loader: UIActivityIndicatorView!
    var webV:WKWebView = WKWebView()
    static var lastModel : String = "";
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loader.isHidden = false
        //Create a webview to show the developments
        self.webV = WKWebView(frame: CGRect(x:0, y:0, width: self.view.bounds.width, height: self.view.bounds.height))
        webV.frame.origin.x = CGFloat(0) 
        webV.navigationDelegate = self
        self.view.addSubview(webV)
        self.webV.configuration.userContentController.add(self, name: "gallery")
        self.webV.configuration.userContentController.add(self, name: "tour")
        self.webV.configuration.userContentController.add(self, name: "plans")
        self.webV.configuration.userContentController.add(self, name: "slick")
        let model = DataHelper.CURRENT_VIEW["modelnum"] as! Int
        DetailsViewController.lastModel = String(model)

        self.webV.load(DevelopmentsViewController.Models[model]!)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        title = webV.title
        loader.isHidden = true
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        print(message.name) // tour, gallery, plans
        print(message.body)
        DetailsViewController.GalleryType = message.name
        switch message.name {
            
        case "slick":
            DetailsViewController.CurrentImage = message.body as! Int
        break;
//        case "gallery":
//            DetailsViewController.GalleryImages = message.body as! NSArray
//            break;
//
//        case "tour":
//        DetailsViewController.GalleryTourImages = message.body as! NSArray
//        break;
//
//        case "plans":
//        DetailsViewController.GalleryFloorPlanImages = message.body as! NSArray
//        break;
        
        default:
            DetailsViewController.GalleryImages = message.body as! NSArray
        break;
        }
        
        if(message.name != "slick"){
        self.performSegue(withIdentifier: "gallery", sender: Any?.self)
        }
    }
}
