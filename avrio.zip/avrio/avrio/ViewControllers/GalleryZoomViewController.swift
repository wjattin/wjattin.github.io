//
//  GalleryZoomViewController.swift
//  avrio
//
//  Created by William Jattin on 3/25/19.
//  Copyright © 2019 William Jattin. All rights reserved.
//

import UIKit

class GalleryZoomViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var imageScrollView: UIScrollView!
    @IBOutlet weak var image: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("loaded gallery zoom")
        print("GalleryViewController.SelectedImage")
        print(GalleryViewController.SelectedImage)
        self.imageScrollView.minimumZoomScale = 1.0
        self.imageScrollView.maximumZoomScale = 6.0

        //imageScrollView.frame = self.view.frame
            
            
            image.isUserInteractionEnabled = true
            image.frame = imageScrollView.frame
            image.image = GalleryViewController.FullScreenImages[GalleryViewController.SelectedImage]
    image.contentMode = UIView.ContentMode.scaleAspectFit
            
            
        }
    

    func viewForZooming(in scrollView: UIScrollView) -> UIView? {
        return self.image
    }
    

}
